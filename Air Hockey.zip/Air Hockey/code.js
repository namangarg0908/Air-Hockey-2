var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var striker = createSprite(200,200,12,12);
striker.shapeColor = "black";
var playerMallet = createSprite(200,350,50,10);
playerMallet.shapeColor = "blue";
var computerMallet = createSprite(200,50,50,10);
computerMallet.shapeColor = "blue";
var goal1 = createSprite(200,28,100,10);
goal1.shapeColor = "yellow";
var goal2 = createSprite(200,372,100,10);
goal2.shapeColor = "yellow";
var line2 = createSprite(0,3.3,800,6.4);
line2.shapeColor = "white";
var line3 = createSprite(3.3,0,6.4,800);
line3.shapeColor = "white";
var line4 = createSprite(0,396.7,800,6.4);
line4.shapeColor = "white";
var line5 = createSprite(396.7,0,6.4,800);
line5.shapeColor = "white";
var line6 = createSprite(0,19,800,6.4);
line6.shapeColor = "white";
var line7 = createSprite(17,0,6.4,800);
line7.shapeColor = "white";
var line8 = createSprite(0,381,800,6.4);
line8.shapeColor = "white";
var line9 = createSprite(383,0,6.4,800);
line9.shapeColor = "white";
var gameState = "serve";
var compscore = 0;
var playerscore = 0;
var line10 = createSprite(200,35,100,3);
line10.shapeColor="green";
var line11 = createSprite(200,365,100,3);
line11.shapeColor="green";
textSize(19);
function draw() {
background("green");
createEdgeSprites();
if(striker.bounceOff(line6)){
playSound("assets/category_app/app_button_1.mp3");
}
if(striker.bounceOff(line7)){
playSound("assets/category_app/app_button_1.mp3");
}
if(striker.bounceOff(line8)){
playSound("assets/category_app/app_button_1.mp3");
}
if(striker.bounceOff(line9)){
playSound("assets/category_app/app_button_1.mp3");
}
if(striker.bounceOff(computerMallet)){
playSound("assets/category_hits/retro_game_simple_impact_1.mp3");
}
if(striker.bounceOff(playerMallet)){
playSound("assets/category_hits/retro_game_simple_impact_1.mp3");
}
playerMallet.bounceOff(line6);
playerMallet.bounceOff(line7);
playerMallet.bounceOff(line8);
playerMallet.bounceOff(line9);
playerMallet.bounceOff(goal2);
if (keyDown("space") && gameState === "serve") {
serve();
gameState = "play";
}
if (striker.isTouching(line10)) {
playSound("assets/category_points/vibrant_game_ding_touch_1.mp3");
playerscore=playerscore+1;
reset();
gameState = "serve";
playerMallet.x = 200;
playerMallet.y = 350;
playerMallet.velocityX = 0;
playerMallet.velocityY = 0;
}
if (striker.isTouching(line11)) {
playSound("assets/category_points/vibrant_game_ding_touch_1.mp3");
compscore=compscore+1;
reset();
gameState = "serve";
playerMallet.x = 200;
playerMallet.y = 350;
playerMallet.velocityX = 0;
playerMallet.velocityY = 0;
}


for (var l = 0;l  < 400; l=l+20) {
line(l, 200, l+10, 200);
stroke("white");
strokeWeight(2);
}   

if (gameState === "serve") {
text("press space to start",130,170);
}
text(compscore,28,185);
text(playerscore,28,228);

computerMallet.x = striker.x;
if (keyDown(UP_ARROW)) {
playerMallet.velocityX = 0;
playerMallet.velocityY = -4;
}
if (keyDown(DOWN_ARROW)) {
playerMallet.velocityX = 0;
playerMallet.velocityY = 4;
}
if (keyDown(RIGHT_ARROW)) {
playerMallet.velocityX = 8;
playerMallet.velocityY = 0;
}
if (keyDown(LEFT_ARROW)) {
playerMallet.velocityX = -8;
playerMallet.velocityY = 0;
}

if (playerscore === 5 || compscore === 5) {
 gameState = "over" ;
 text("Game Over",170,160);
 text("Press 'r'to restart",150,180);
}
if (keyDown("r")&& gameState === "over") {
 gameState = "serve" ;
 compscore = 0;
 playerscore=0;
}
if (playerMallet.y < 200) {
playerMallet.x = 200;
playerMallet.y = 350;
}
if (compscore===5&&gameState==="over"&&playerscore<5) {
text("Better Luck Next Time",120,282);
}
if (playerscore===5&&gameState==="over"&& compscore<5) {
text("Better Luck Next Time",125,118);
}
if (compscore===5&&gameState==="over"&&playerscore<5) {
text("You Win",170,122);
}
if (playerscore===5&&gameState==="over"&& compscore<5) {
text("You Win",170,268);
}
drawSprites();
}
function serve(){
striker.velocityX=6;
striker.velocityY=-6;
}

function reset(){
striker.x = 200;
striker.y = 200;
striker.velocityX = 0;
striker.velocityY = 0;
}












// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
